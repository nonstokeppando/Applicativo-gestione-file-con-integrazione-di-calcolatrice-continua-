package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.scene.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FMSampleController {
	String cont;
	String path = "C:\\Users\\Rocco di Martino\\OneDrive\\Desktop\\fileProva.txt";
	File file = new File(path);

	String directoryPath = "C:\\Users\\Rocco di Martino\\OneDrive\\Desktop\\Cartella File manager\\directorty";
	File directory = new File(directoryPath);

	String pathSposta = "Desktop";
	@FXML
	private Label lblTesto;

	@FXML
	private Button BtnCreaDirectory;

	@FXML
	private Button btnCancellaDirectory;

	@FXML
	private Button btnScrivi;

	@FXML
	private Button BtnLeggi;

	@FXML
	private Button btnCancellaFile;

	@FXML
	private Button Btncrea;

	@FXML
	private TextField txtOutputLeggi;

	@FXML
	private TextField txtInputScrivi;

	@FXML
	private Button BtnCopia;

	@FXML
	private Button BtnSposta;

	@FXML
	private Button btnCalcolatrice;

	@FXML
	void handleBtnCalcolatrice(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("BellaSample.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML
	void handleBtnCreaDirectory(ActionEvent event) {
		if (!directory.isDirectory()) {
			directory.mkdirs();
			System.out.println("Cartella creata");
		} else {
			System.out.println("La directory esiste giá");
		}
	}

	@FXML
	void handleBtnLeggi(ActionEvent event) {
		ArrayList<Character> al = new ArrayList<Character>();
		try {
			FileReader fr = new FileReader(file);
			Scanner r = new Scanner(fr);
			cont = "";
			while (r.hasNextLine()) {
				cont += r.nextLine() + "\n";
				txtOutputLeggi.setText(cont);

			}
			System.out.println("File letto");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@FXML
	void handleBtncrea(ActionEvent event) {
		try {
			if (file.exists()) {
				System.out.println("il file esiste giá");
			} else if (file.createNewFile()) {
				System.out.println("il file e' stato creato");
			} else {
				System.out.println("il file non puo' essere creato ");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML
	void handlebtnCancellaDirectory(ActionEvent event) {
		if (directory.delete()) {
			System.out.println("Directory cancellata");
		} else {
			System.out.println("La directory non esiste");
		}

	}

	@FXML
	void handlebtnCancellaFile(ActionEvent event) {
		if (file.delete()) {
			System.out.println("Ho cancellato il file");
		} else {
			System.out.println("Il file non esiste");
		}
	}

	@FXML
	void handlebtnScrivi(ActionEvent event) {
		try {
			FileWriter fw = new FileWriter(file);
			fw.write(txtInputScrivi.getText());
			fw.flush();
			fw.close();
			txtInputScrivi.setText("");
			System.out.println("Ho scritto sul file");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML
	void handletxtInputScrivi(ActionEvent event) {

	}

	@FXML
	void handletxtOutputLeggi(ActionEvent event) {

	}

}
