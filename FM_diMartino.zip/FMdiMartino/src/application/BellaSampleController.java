/**
 * Sample Skeleton for 'BellaSample.fxml' Controller Class
 */

package application;

import java.io.IOException;
import javafx.scene.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class BellaSampleController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="virgola"
    private Button virgola; // Value injected by FXMLLoader

    @FXML // fx:id="zero"
    private Button zero; // Value injected by FXMLLoader

    @FXML // fx:id="uguale"
    private Button uguale; // Value injected by FXMLLoader

    @FXML // fx:id="sette"
    private Button sette; // Value injected by FXMLLoader

    @FXML // fx:id="quattro"
    private Button quattro; // Value injected by FXMLLoader

    @FXML // fx:id="uno"
    private Button uno; // Value injected by FXMLLoader

    @FXML // fx:id="otto"
    private Button otto; // Value injected by FXMLLoader

    @FXML // fx:id="nove"
    private Button nove; // Value injected by FXMLLoader

    @FXML // fx:id="cinque"
    private Button cinque; // Value injected by FXMLLoader

    @FXML // fx:id="sei"
    private Button sei; // Value injected by FXMLLoader

    @FXML // fx:id="due"
    private Button due; // Value injected by FXMLLoader
    
    @FXML
    private Button btnTorna;
    
    @FXML // fx:id="tre"
    private Button tre; // Value injected by FXMLLoader

    @FXML // fx:id="divisione"
    private Button divisione; // Value injected by FXMLLoader

    @FXML // fx:id="moltiplicazione"
    private Button moltiplicazione; // Value injected by FXMLLoader

    @FXML // fx:id="sottrazione"
    private Button sottrazione; // Value injected by FXMLLoader

    @FXML // fx:id="somma"
    private Button somma; // Value injected by FXMLLoader

    @FXML // fx:id="canc"
    private Button canc; // Value injected by FXMLLoader

    @FXML // fx:id="risultato"
    private Label risultato; // Value injected by FXMLLoader

    @FXML
    void cancella(ActionEvent event) {
    	risultato.setText("0");
    	inizio=true;
    }

    ArrayList<Double> dato = new ArrayList<Double>();
    boolean inizio = true;
    String segno;
    double result;
    
    @FXML
    void handleBtnTorna(ActionEvent event) {
    	try {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("FMSample.fxml"));
    		Parent root = loader.load();
    		Stage stage =
    		(Stage)((Node)event.getSource()).getScene().getWindow(
    		);
    		Scene scene = new Scene(root);
    		stage.setScene(scene);
    		stage.show();
    		} catch (IOException e) {
    		e.printStackTrace();
    		}
    }
    
    @FXML
    void cinque(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("5");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "5");
    	}
    	
    }

    @FXML
    void divisione(ActionEvent event) {
    	if(inizio) {
    		
    	}else {
    		dato.add(Double.parseDouble(risultato.getText()));
    		risultato.setText("�");
    		segno="divisione";
    		inizio = true;
    	}
    }

    @FXML
    void due(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("2");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "2");
    	}
    }

    @FXML
    void moltiplicazione(ActionEvent event) {
    	if(inizio) {
    		
    	}else {
    		dato.add(Double.parseDouble(risultato.getText()));
    		risultato.setText("x");
    		segno="moltiplicazione";
    		inizio = true;
    	}
    }

    @FXML
    void nove(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("9");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "9");
    	}
    }

    @FXML
    void otto(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("8");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "8");
    	}
    }

    @FXML
    void quattro(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("4");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "4");
    	}
    }

    @FXML
    void sei(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("6");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "6");
    	}
    }

    @FXML
    void sette(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("7");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "7");
    	}
    }

    @FXML
    void somma(ActionEvent event) {
    	if(inizio) {
    		
    	}else {
    		dato.add(Double.parseDouble(risultato.getText()));
    		risultato.setText("+");
    		segno = "somma";
    		inizio = true;
    	}
    }

    @FXML
    void sottrazione(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("-");
    	}else {
    		dato.add(Double.parseDouble(risultato.getText()));
    		risultato.setText(risultato.getText() + "-");
    		segno="sottrazione";
    		inizio = true;
    	}
    }

    @FXML
    void tre(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("3");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "3");
    	}
    }

    @FXML
    void uguale(ActionEvent event) {
    	if(inizio) {
    		
    	}else {
    		
    		if(segno.equals("somma")) {
    			dato.add(Double.parseDouble(risultato.getText()));
    		for(int i=0;i<dato.size();i++) {
    			result=dato.get(i)+dato.get(i+1);
    			i++;
    		}
    		risultato.setText(result + "");
    		}else if(segno.equals("sottrazione")) {
    			dato.add(Double.parseDouble(risultato.getText()));
    			for(int i=0;i<dato.size();i++) {
        			result=dato.get(i)-dato.get(i+1);
        			i++;
        		}
        		risultato.setText(result + "");
    		}else if(segno.equals("moltiplicazione")) {
    			dato.add(Double.parseDouble(risultato.getText()));
    			for(int i=0;i<dato.size();i++) {
        			result=dato.get(i)*dato.get(i+1);
        			i++;
        		}
        		risultato.setText(result + "");
    		}else if(segno.equals("divisione")) {
    			dato.add(Double.parseDouble(risultato.getText()));
    			for(int i=0;i<dato.size();i++) {
        			result=dato.get(i)/dato.get(i+1);
        			i++;
        		}
        		risultato.setText(result + "");
    		}
    		
    	}
    }

    @FXML
    void uno(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("1");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "1");
    	}
    }

    @FXML
    void virgola(ActionEvent event) {
    	if(inizio) {
    		
    	}else {
    		risultato.setText(risultato.getText() + ".");
    	}
    }

    @FXML
    void zero(ActionEvent event) {
    	if(inizio) {
    		risultato.setText("0");
    		inizio=false;
    	}else {
    		risultato.setText(risultato.getText() + "0");
    	}
    }

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert virgola != null : "fx:id=\"virgola\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert zero != null : "fx:id=\"zero\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert uguale != null : "fx:id=\"uguale\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert sette != null : "fx:id=\"sette\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert quattro != null : "fx:id=\"quattro\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert uno != null : "fx:id=\"uno\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert otto != null : "fx:id=\"otto\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert nove != null : "fx:id=\"nove\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert cinque != null : "fx:id=\"cinque\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert sei != null : "fx:id=\"sei\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert due != null : "fx:id=\"due\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert tre != null : "fx:id=\"tre\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert divisione != null : "fx:id=\"divisione\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert moltiplicazione != null : "fx:id=\"moltiplicazione\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert sottrazione != null : "fx:id=\"sottrazione\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert somma != null : "fx:id=\"somma\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert canc != null : "fx:id=\"canc\" was not injected: check your FXML file 'BellaSample.fxml'.";
        assert risultato != null : "fx:id=\"risultato\" was not injected: check your FXML file 'BellaSample.fxml'.";

    }
}
